#!/usr/bin/env python3
"""Sanity checks: XML validity + R.* references present in resources."""
import os
import re
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "app", "src", "main", "res")
SRC = os.path.join(ROOT, "app", "src", "main", "java")
MANIFEST = os.path.join(ROOT, "app", "src", "main", "AndroidManifest.xml")

problems = []

# --- 1. XML validity ---
xml_files = [MANIFEST]
for dirpath, _dirs, files in os.walk(RES):
    for f in files:
        if f.endswith(".xml"):
            xml_files.append(os.path.join(dirpath, f))
for dirpath, _dirs, files in os.walk(os.path.join(ROOT, ".github")):
    pass

for path in xml_files:
    try:
        ET.parse(path)
    except Exception as exc:  # noqa: BLE001
        problems.append("XML INVALID %s -> %s" % (os.path.relpath(path, ROOT), exc))

# --- 2. collect resources ---
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

layout_ids = {}   # layout name -> set of ids
for dirpath, _dirs, files in os.walk(RES):
    base = os.path.basename(dirpath)
    if not base.startswith("layout"):
        continue
    for f in files:
        if not f.endswith(".xml"):
            continue
        text = open(os.path.join(dirpath, f), encoding="utf-8").read()
        ids = set(re.findall(r'android:id="@\+id/([A-Za-z0-9_]+)"', text))
        layout_ids[f[:-4]] = ids

all_ids = set()
for ids in layout_ids.values():
    all_ids |= ids

def values_names(kind):
    out = set()
    vdir = os.path.join(RES, "values")
    if not os.path.isdir(vdir):
        return out
    for f in os.listdir(vdir):
        if not f.endswith(".xml"):
            continue
        try:
            tree = ET.parse(os.path.join(vdir, f))
        except Exception:
            continue
        for el in tree.getroot():
            tag = el.tag
            name = el.get("name")
            if not name:
                continue
            if tag == kind:
                out.add(name)
            if tag == "item" and el.get("type") == kind:
                out.add(name)
    return out

colors = values_names("color")
strings = values_names("string")
styles = values_names("style")

drawables = set()
for dirpath, _dirs, files in os.walk(RES):
    base = os.path.basename(dirpath)
    if base.startswith("drawable"):
        for f in files:
            drawables.add(os.path.splitext(f)[0])
    if base.startswith("mipmap"):
        for f in files:
            drawables.add(os.path.splitext(f)[0])

mipmaps = set()
for dirpath, _dirs, files in os.walk(RES):
    if os.path.basename(dirpath).startswith("mipmap"):
        for f in files:
            mipmaps.add(os.path.splitext(f)[0])

# --- 3. Kotlin references ---
kt_files = []
for dirpath, _dirs, files in os.walk(SRC):
    for f in files:
        if f.endswith(".kt"):
            kt_files.append(os.path.join(dirpath, f))

for path in kt_files:
    text = open(path, encoding="utf-8").read()
    rel = os.path.relpath(path, ROOT)
    for name in set(re.findall(r"R\.id\.([A-Za-z0-9_]+)", text)):
        if name not in all_ids:
            problems.append("MISSING id @+id/%s used in %s" % (name, rel))
    for name in set(re.findall(r"R\.color\.([A-Za-z0-9_]+)", text)):
        if name not in colors:
            problems.append("MISSING color %s used in %s" % (name, rel))
    for name in set(re.findall(r"R\.string\.([A-Za-z0-9_]+)", text)):
        if name not in strings:
            problems.append("MISSING string %s used in %s" % (name, rel))
    for name in set(re.findall(r"R\.drawable\.([A-Za-z0-9_]+)", text)):
        if name not in drawables:
            problems.append("MISSING drawable %s used in %s" % (name, rel))
    for name in set(re.findall(r"R\.layout\.([A-Za-z0-9_]+)", text)):
        if name not in layout_ids:
            problems.append("MISSING layout %s used in %s" % (name, rel))

# --- 4. layout -> resource references ---
for dirpath, _dirs, files in os.walk(RES):
    base = os.path.basename(dirpath)
    if not (base.startswith("layout") or base.startswith("drawable")):
        continue
    for f in files:
        if not f.endswith(".xml"):
            continue
        text = open(os.path.join(dirpath, f), encoding="utf-8").read()
        rel = os.path.join(base, f)
        for name in set(re.findall(r"@color/([A-Za-z0-9_]+)", text)):
            if name not in colors:
                problems.append("MISSING color %s in %s" % (name, rel))
        for name in set(re.findall(r"@string/([A-Za-z0-9_]+)", text)):
            if name not in strings:
                problems.append("MISSING string %s in %s" % (name, rel))
        for name in set(re.findall(r"@drawable/([A-Za-z0-9_]+)", text)):
            if name not in drawables:
                problems.append("MISSING drawable %s in %s" % (name, rel))

# --- 5. manifest references ---
mtext = open(MANIFEST, encoding="utf-8").read()
for name in set(re.findall(r"@mipmap/([A-Za-z0-9_]+)", mtext)):
    if name not in mipmaps:
        problems.append("MISSING mipmap %s in manifest" % name)
for name in set(re.findall(r"@string/([A-Za-z0-9_]+)", mtext)):
    if name not in strings:
        problems.append("MISSING string %s in manifest" % name)
for name in set(re.findall(r'android:theme="@style/([A-Za-z0-9_.]+)"', mtext)):
    if name not in styles:
        problems.append("MISSING style %s in manifest" % name)
for name in set(re.findall(r"@drawable/([A-Za-z0-9_]+)", mtext)):
    if name not in drawables:
        problems.append("MISSING drawable %s in manifest" % name)

# manifest classes exist?
for cls in set(re.findall(r'android:name="(\.[A-Za-z0-9_.]+)"', mtext)):
    parts = cls.lstrip(".").split(".")
    expected = os.path.join(SRC, "ir", "systemguard", *parts[:-1], parts[-1] + ".kt")
    if not os.path.isfile(expected):
        problems.append("MISSING class file for %s (expected %s)" % (cls, os.path.relpath(expected, ROOT)))

print("kotlin files: %d" % len(kt_files))
print("layouts: %s" % ", ".join(sorted(layout_ids)))
print("colors: %d, strings: %d, drawables: %d, mipmaps: %d" % (len(colors), len(strings), len(drawables), len(mipmaps)))
print("ids declared: %d" % len(all_ids))

if problems:
    print("\n--- PROBLEMS (%d) ---" % len(problems))
    for p in problems:
        print(p)
    sys.exit(1)
print("\nOK: no missing references, all XML parses")
