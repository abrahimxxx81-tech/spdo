package ir.systemguard.ui

import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import ir.systemguard.R
import ir.systemguard.data.Prefs
import ir.systemguard.monitor.DeviceProfile
import ir.systemguard.service.GuardService

class SettingsActivity : AppCompatActivity() {

	private lateinit var txtInterval: TextView
	private lateinit var txtRamWarn: TextView
	private lateinit var txtRamCrit: TextView
	private lateinit var txtTempWarn: TextView
	private lateinit var txtTempCrit: TextView
	private lateinit var txtCooldown: TextView

	private lateinit var seekInterval: SeekBar
	private lateinit var seekRamWarn: SeekBar
	private lateinit var seekRamCrit: SeekBar
	private lateinit var seekTempWarn: SeekBar
	private lateinit var seekTempCrit: SeekBar
	private lateinit var seekCooldown: SeekBar

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_settings)

		val swAuto = findViewById<SwitchCompat>(R.id.sw_auto_clean)
		val swAlerts = findViewById<SwitchCompat>(R.id.sw_alerts)
		val swBoot = findViewById<SwitchCompat>(R.id.sw_boot)
		val swSystem = findViewById<SwitchCompat>(R.id.sw_system_apps)

		swAuto.isChecked = Prefs.autoClean(this)
		swAlerts.isChecked = Prefs.alerts(this)
		swBoot.isChecked = Prefs.startOnBoot(this)
		swSystem.isChecked = Prefs.includeSystemApps(this)

		swAuto.setOnCheckedChangeListener { _, v -> Prefs.setAutoClean(this, v) }
		swAlerts.setOnCheckedChangeListener { _, v -> Prefs.setAlerts(this, v) }
		swBoot.setOnCheckedChangeListener { _, v -> Prefs.setStartOnBoot(this, v) }
		swSystem.setOnCheckedChangeListener { _, v ->
			Prefs.setIncludeSystemApps(this, v)
			if (v) {
				Toast.makeText(
					this,
					"حواست باشد: بستن برنامه‌های سیستمی ممکن است روی اعلان‌ها اثر بگذارد",
					Toast.LENGTH_LONG
				).show()
			}
		}

		txtInterval = findViewById(R.id.txt_interval)
		txtRamWarn = findViewById(R.id.txt_ram_warn)
		txtRamCrit = findViewById(R.id.txt_ram_crit)
		txtTempWarn = findViewById(R.id.txt_temp_warn)
		txtTempCrit = findViewById(R.id.txt_temp_crit)
		txtCooldown = findViewById(R.id.txt_cooldown)

		seekInterval = findViewById(R.id.seek_interval)
		seekRamWarn = findViewById(R.id.seek_ram_warn)
		seekRamCrit = findViewById(R.id.seek_ram_crit)
		seekTempWarn = findViewById(R.id.seek_temp_warn)
		seekTempCrit = findViewById(R.id.seek_temp_crit)
		seekCooldown = findViewById(R.id.seek_cooldown)

		bind(seekInterval) { progress ->
			val value = (progress + 2).coerceIn(2, 30)
			Prefs.setIntervalSec(this, value)
			txtInterval.text = "فاصله بررسی وضعیت: هر $value ثانیه"
		}
		bind(seekRamWarn) { progress ->
			val value = (progress + 5).coerceIn(5, 40)
			Prefs.setRamWarnFree(this, value)
			txtRamWarn.text = "هشدار وقتی رم آزاد کمتر از: $value٪"
		}
		bind(seekRamCrit) { progress ->
			val value = (progress + 3).coerceIn(3, 33)
			Prefs.setRamCritFree(this, value)
			txtRamCrit.text = "وضعیت بحرانی وقتی رم آزاد کمتر از: $value٪"
		}
		bind(seekTempWarn) { progress ->
			val value = (progress + 35).coerceIn(35, 60)
			Prefs.setTempWarn(this, value)
			txtTempWarn.text = "هشدار دما از: $value درجه"
		}
		bind(seekTempCrit) { progress ->
			val value = (progress + 38).coerceIn(38, 63)
			Prefs.setTempCrit(this, value)
			txtTempCrit.text = "دمای بحرانی از: $value درجه"
		}
		bind(seekCooldown) { progress ->
			val value = ((progress + 3) * 10).coerceIn(30, 600)
			Prefs.setCooldownSec(this, value)
			txtCooldown.text = "کمترین فاصله بین دو پاکسازی خودکار: $value ثانیه"
		}

		findViewById<Button>(R.id.btn_apply_tuned).setOnClickListener {
			val message = DeviceProfile.applyTuned(this)
			loadValues()
			Toast.makeText(this, message, Toast.LENGTH_LONG).show()
			if (Prefs.guardEnabled(this)) GuardService.start(this)
		}

		loadValues()
	}

	private fun bind(seek: SeekBar, onValue: (Int) -> Unit) {
		seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
			override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
				onValue(progress)
			}

			override fun onStartTrackingTouch(bar: SeekBar?) {}
			override fun onStopTrackingTouch(bar: SeekBar?) {}
		})
	}

	private fun loadValues() {
		seekInterval.progress = (Prefs.intervalSec(this) - 2).coerceIn(0, seekInterval.max)
		seekRamWarn.progress = (Prefs.ramWarnFree(this) - 5).coerceIn(0, seekRamWarn.max)
		seekRamCrit.progress = (Prefs.ramCritFree(this) - 3).coerceIn(0, seekRamCrit.max)
		seekTempWarn.progress = (Prefs.tempWarn(this) - 35).coerceIn(0, seekTempWarn.max)
		seekTempCrit.progress = (Prefs.tempCrit(this) - 38).coerceIn(0, seekTempCrit.max)
		seekCooldown.progress = ((Prefs.cooldownSec(this) / 10) - 3).coerceIn(0, seekCooldown.max)

		txtInterval.text = "فاصله بررسی وضعیت: هر ${Prefs.intervalSec(this)} ثانیه"
		txtRamWarn.text = "هشدار وقتی رم آزاد کمتر از: ${Prefs.ramWarnFree(this)}٪"
		txtRamCrit.text = "وضعیت بحرانی وقتی رم آزاد کمتر از: ${Prefs.ramCritFree(this)}٪"
		txtTempWarn.text = "هشدار دما از: ${Prefs.tempWarn(this)} درجه"
		txtTempCrit.text = "دمای بحرانی از: ${Prefs.tempCrit(this)} درجه"
		txtCooldown.text = "کمترین فاصله بین دو پاکسازی خودکار: ${Prefs.cooldownSec(this)} ثانیه"
	}
}
