package ir.systemguard.data

import android.content.Context
import android.content.SharedPreferences

/** تمام تنطیمات نگهبان در یک جا. */
object Prefs {

	private const val NAME = "guard_prefs"

	private fun sp(c: Context): SharedPreferences =
		c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

	// --- وضعیت کلی ---
	fun guardEnabled(c: Context): Boolean = sp(c).getBoolean("guard_enabled", true)
	fun setGuardEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("guard_enabled", v).apply()

	fun autoClean(c: Context): Boolean = sp(c).getBoolean("auto_clean", true)
	fun setAutoClean(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_clean", v).apply()

	fun alerts(c: Context): Boolean = sp(c).getBoolean("alerts", true)
	fun setAlerts(c: Context, v: Boolean) = sp(c).edit().putBoolean("alerts", v).apply()

	fun startOnBoot(c: Context): Boolean = sp(c).getBoolean("start_on_boot", true)
	fun setStartOnBoot(c: Context, v: Boolean) = sp(c).edit().putBoolean("start_on_boot", v).apply()

	fun includeSystemApps(c: Context): Boolean = sp(c).getBoolean("include_system", false)
	fun setIncludeSystemApps(c: Context, v: Boolean) =
		sp(c).edit().putBoolean("include_system", v).apply()

	// --- آستانه‌ها ---
	fun intervalSec(c: Context): Int = sp(c).getInt("interval_sec", 6)
	fun setIntervalSec(c: Context, v: Int) = sp(c).edit().putInt("interval_sec", v).apply()

	/** درصد رم آزاد که زیر آن هشدار محسوب می‌شود. */
	fun ramWarnFree(c: Context): Int = sp(c).getInt("ram_warn_free", 18)
	fun setRamWarnFree(c: Context, v: Int) = sp(c).edit().putInt("ram_warn_free", v).apply()

	/** درصد رم آزاد که زیر آن وضعیت بحرانی است. */
	fun ramCritFree(c: Context): Int = sp(c).getInt("ram_crit_free", 12)
	fun setRamCritFree(c: Context, v: Int) = sp(c).edit().putInt("ram_crit_free", v).apply()

	fun tempWarn(c: Context): Int = sp(c).getInt("temp_warn", 42)
	fun setTempWarn(c: Context, v: Int) = sp(c).edit().putInt("temp_warn", v).apply()

	fun tempCrit(c: Context): Int = sp(c).getInt("temp_crit", 46)
	fun setTempCrit(c: Context, v: Int) = sp(c).edit().putInt("temp_crit", v).apply()

	/** کمترین فاصله بین دو پاکسازی خودکار (بر حسب ثانیه). */
	fun cooldownSec(c: Context): Int = sp(c).getInt("cooldown_sec", 90)
	fun setCooldownSec(c: Context, v: Int) = sp(c).edit().putInt("cooldown_sec", v).apply()

	// --- لیست محافطت‌شده ---
	fun whitelist(c: Context): MutableSet<String> {
		val stored = sp(c).getStringSet("whitelist", null) ?: emptySet<String>()
		return HashSet(stored)
	}

	fun isWhitelisted(c: Context, pkg: String): Boolean = whitelist(c).contains(pkg)

	fun setWhitelisted(c: Context, pkg: String, on: Boolean) {
		val set = whitelist(c)
		if (on) set.add(pkg) else set.remove(pkg)
		sp(c).edit().putStringSet("whitelist", set).apply()
	}

	fun addWhitelist(c: Context, pkgs: Collection<String>) {
		val set = whitelist(c)
		set.addAll(pkgs)
		sp(c).edit().putStringSet("whitelist", set).apply()
	}

	fun clearWhitelist(c: Context) {
		sp(c).edit().putStringSet("whitelist", HashSet()).apply()
	}

	// --- آمار ---
	fun freedTotalMb(c: Context): Long = sp(c).getLong("freed_total_mb", 0L)
	fun addFreed(c: Context, mb: Long) {
		if (mb <= 0L) return
		sp(c).edit().putLong("freed_total_mb", freedTotalMb(c) + mb).apply()
	}

	fun cleanCount(c: Context): Int = sp(c).getInt("clean_count", 0)
	fun bumpCleanCount(c: Context) = sp(c).edit().putInt("clean_count", cleanCount(c) + 1).apply()

	fun hangCount(c: Context): Int = sp(c).getInt("hang_count", 0)
	fun bumpHangCount(c: Context) = sp(c).edit().putInt("hang_count", hangCount(c) + 1).apply()
}
