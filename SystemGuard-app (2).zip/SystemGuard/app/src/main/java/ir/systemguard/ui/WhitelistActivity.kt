package ir.systemguard.ui

import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import ir.systemguard.R
import ir.systemguard.data.Prefs
import ir.systemguard.engine.ProtectedApps

/** کاربر انتخاب می‌کند کدام برنامه‌ها هرگز بسته نشوند. */
class WhitelistActivity : AppCompatActivity() {

	private class Row(
		val label: String,
		val pkg: String,
		val icon: Drawable?,
		var keep: Boolean
	)

	private val rows = ArrayList<Row>()
	private var adapter: Adapter? = null

	private inner class Adapter : BaseAdapter() {
		override fun getCount(): Int = rows.size
		override fun getItem(position: Int): Any = rows[position]
		override fun getItemId(position: Int): Long = position.toLong()

		override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
			val view = convertView ?: LayoutInflater.from(this@WhitelistActivity)
				.inflate(R.layout.item_app, parent, false)
			val row = rows[position]
			view.findViewById<TextView>(R.id.txt_label).text = row.label
			view.findViewById<TextView>(R.id.txt_pkg).text = row.pkg
			view.findViewById<CheckBox>(R.id.chk_protect).isChecked = row.keep
			val img = view.findViewById<ImageView>(R.id.img_icon)
			if (row.icon != null) img.setImageDrawable(row.icon) else img.setImageResource(R.drawable.ic_shield)
			return view
		}
	}

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_whitelist)

		val list = findViewById<ListView>(R.id.list_apps)
		val loading = findViewById<TextView>(R.id.txt_loading)
		adapter = Adapter()
		list.adapter = adapter

		list.setOnItemClickListener { _, _, position, _ ->
			if (position < rows.size) {
				val row = rows[position]
				row.keep = !row.keep
				Prefs.setWhitelisted(this, row.pkg, row.keep)
				adapter?.notifyDataSetChanged()
			}
		}

		findViewById<Button>(R.id.btn_suggested).setOnClickListener {
			Prefs.addWhitelist(this, ProtectedApps.SUGGESTED)
			val saved = Prefs.whitelist(this)
			for (row in rows) row.keep = saved.contains(row.pkg)
			adapter?.notifyDataSetChanged()
			Toast.makeText(this, "پیام‌رسان‌ها و زنگ هشدار محافطت شدند", Toast.LENGTH_SHORT).show()
		}

		findViewById<Button>(R.id.btn_clear_all).setOnClickListener {
			Prefs.clearWhitelist(this)
			for (row in rows) row.keep = false
			adapter?.notifyDataSetChanged()
		}

		Thread {
			val loaded = loadApps()
			runOnUiThread {
				rows.clear()
				rows.addAll(loaded)
				loading.visibility = View.GONE
				adapter?.notifyDataSetChanged()
			}
		}.start()
	}

	private fun loadApps(): List<Row> {
		val pm = packageManager
		val saved = Prefs.whitelist(this)
		val always = ProtectedApps.build(this)
		val out = ArrayList<Row>()

		val apps: List<ApplicationInfo> = try {
			pm.getInstalledApplications(0)
		} catch (t: Throwable) {
			emptyList()
		}

		for (info in apps) {
			val pkg = info.packageName ?: continue
			if (pkg == packageName) continue
			if (always.contains(pkg)) continue
			val launchable = try {
				pm.getLaunchIntentForPackage(pkg) != null
			} catch (t: Throwable) {
				false
			}
			if (!launchable) continue

			val label = try {
				pm.getApplicationLabel(info).toString()
			} catch (t: Throwable) {
				pkg
			}
			val icon = try {
				pm.getApplicationIcon(info)
			} catch (t: Throwable) {
				null
			}
			out.add(Row(label, pkg, icon, saved.contains(pkg)))
		}

		out.sortWith(compareBy({ !it.keep }, { it.label }))
		return out
	}
}
