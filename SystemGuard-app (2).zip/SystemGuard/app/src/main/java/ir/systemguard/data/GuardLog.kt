package ir.systemguard.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** دفترچه رویدادها: آخرین ۱۲۰ اتفاق را نگه می‌دارد. */
object GuardLog {

	private const val NAME = "guard_log"
	private const val KEY = "entries"
	private const val MAX = 120

	const val INFO = "info"
	const val WARN = "warn"
	const val CRIT = "crit"

	class Entry(val time: Long, val level: String, val text: String)

	private fun sp(c: Context) =
		c.applicationContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)

	@Synchronized
	fun add(c: Context, level: String, text: String) {
		try {
			val arr = JSONArray(sp(c).getString(KEY, "[]") ?: "[]")
			val o = JSONObject()
			o.put("t", System.currentTimeMillis())
			o.put("l", level)
			o.put("m", text)
			arr.put(o)

			val trimmed = JSONArray()
			val start = if (arr.length() > MAX) arr.length() - MAX else 0
			for (i in start until arr.length()) {
				trimmed.put(arr.get(i))
			}
			sp(c).edit().putString(KEY, trimmed.toString()).apply()
		} catch (t: Throwable) {
			// ignore
		}
	}

	fun all(c: Context): List<Entry> {
		val out = ArrayList<Entry>()
		try {
			val arr = JSONArray(sp(c).getString(KEY, "[]") ?: "[]")
			for (i in 0 until arr.length()) {
				val o = arr.optJSONObject(i) ?: continue
				out.add(
					Entry(
						o.optLong("t", 0L),
						o.optString("l", INFO),
						o.optString("m", "")
					)
				)
			}
		} catch (t: Throwable) {
			// ignore
		}
		out.reverse()
		return out
	}

	fun clear(c: Context) {
		sp(c).edit().putString(KEY, "[]").apply()
	}
}
