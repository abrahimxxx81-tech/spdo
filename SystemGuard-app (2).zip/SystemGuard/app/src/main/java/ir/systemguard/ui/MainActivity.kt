package ir.systemguard.ui

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import ir.systemguard.R
import ir.systemguard.data.GuardLog
import ir.systemguard.data.GuardState
import ir.systemguard.data.Prefs
import ir.systemguard.engine.GuardEngine
import ir.systemguard.engine.UsageHelper
import ir.systemguard.monitor.DeviceProfile
import ir.systemguard.monitor.JankMonitor
import ir.systemguard.monitor.StatsCollector
import ir.systemguard.monitor.StatsSnapshot
import ir.systemguard.service.GuardService
import ir.systemguard.service.WatchdogReceiver
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

	private val ui = Handler(Looper.getMainLooper())
	private val timeFmt = SimpleDateFormat("HH:mm", Locale.US)

	private lateinit var switchGuard: SwitchCompat
	private lateinit var txtLevel: TextView
	private lateinit var txtReasons: TextView
	private lateinit var txtRam: TextView
	private lateinit var barRam: ProgressBar
	private lateinit var rowSwap: LinearLayout
	private lateinit var txtSwap: TextView
	private lateinit var barSwap: ProgressBar
	private lateinit var txtCpu: TextView
	private lateinit var barCpu: ProgressBar
	private lateinit var txtTemp: TextView
	private lateinit var txtStorage: TextView
	private lateinit var txtJank: TextView
	private lateinit var txtSession: TextView
	private lateinit var txtDevice: TextView
	private lateinit var txtPermBattery: TextView
	private lateinit var txtPermUsage: TextView
	private lateinit var containerLog: LinearLayout

	private val refresh = object : Runnable {
		override fun run() {
			try {
				render()
			} catch (t: Throwable) {
				// ignore
			}
			ui.postDelayed(this, 1500L)
		}
	}

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		switchGuard = findViewById(R.id.switch_guard)
		txtLevel = findViewById(R.id.txt_status_level)
		txtReasons = findViewById(R.id.txt_status_reasons)
		txtRam = findViewById(R.id.txt_ram)
		barRam = findViewById(R.id.bar_ram)
		rowSwap = findViewById(R.id.row_swap)
		txtSwap = findViewById(R.id.txt_swap)
		barSwap = findViewById(R.id.bar_swap)
		txtCpu = findViewById(R.id.txt_cpu)
		barCpu = findViewById(R.id.bar_cpu)
		txtTemp = findViewById(R.id.txt_temp)
		txtStorage = findViewById(R.id.txt_storage)
		txtJank = findViewById(R.id.txt_jank)
		txtSession = findViewById(R.id.txt_session)
		txtDevice = findViewById(R.id.txt_device)
		txtPermBattery = findViewById(R.id.txt_perm_battery)
		txtPermUsage = findViewById(R.id.txt_perm_usage)
		containerLog = findViewById(R.id.container_log)

		switchGuard.isChecked = Prefs.guardEnabled(this)
		switchGuard.text = if (switchGuard.isChecked) "فعال" else "خاموش"
		switchGuard.setOnCheckedChangeListener { _, checked ->
			Prefs.setGuardEnabled(this, checked)
			switchGuard.text = if (checked) "فعال" else "خاموش"
			if (checked) {
				GuardService.start(this)
				WatchdogReceiver.schedule(this)
				GuardLog.add(this, GuardLog.INFO, "نگهبان فعال شد")
			} else {
				GuardService.stop(this)
				WatchdogReceiver.cancel(this)
			}
		}

		findViewById<Button>(R.id.btn_boost).setOnClickListener {
			if (!Prefs.guardEnabled(this)) {
				Prefs.setGuardEnabled(this, true)
				switchGuard.isChecked = true
			}
			GuardService.boost(this)
			Toast.makeText(this, "در حال آزادسازی رم...", Toast.LENGTH_SHORT).show()
		}

		findViewById<Button>(R.id.btn_whitelist).setOnClickListener {
			startActivity(Intent(this, WhitelistActivity::class.java))
		}

		findViewById<Button>(R.id.btn_settings).setOnClickListener {
			startActivity(Intent(this, SettingsActivity::class.java))
		}

		findViewById<Button>(R.id.btn_perm_battery).setOnClickListener { requestBatteryExemption() }
		findViewById<Button>(R.id.btn_perm_usage).setOnClickListener { openUsageAccess() }
		findViewById<Button>(R.id.btn_perm_autostart).setOnClickListener { openAutostart() }

		findViewById<Button>(R.id.btn_clear_log).setOnClickListener {
			GuardLog.clear(this)
			render()
		}

		askNotificationPermission()

		if (Prefs.guardEnabled(this)) {
			GuardService.start(this)
			WatchdogReceiver.schedule(this)
		}
	}

	override fun onResume() {
		super.onResume()
		JankMonitor.start()
		ui.removeCallbacks(refresh)
		ui.post(refresh)
	}

	override fun onPause() {
		ui.removeCallbacks(refresh)
		JankMonitor.stop()
		super.onPause()
	}

	// ---------------- رسم وضعیت ----------------

	private fun render() {
		val fresh = System.currentTimeMillis() - GuardState.updatedAt < 12_000L
		val s: StatsSnapshot = if (fresh) {
			GuardState.snapshot ?: StatsCollector.sample(this)
		} else {
			StatsCollector.sample(this)
		}
		val v = if (fresh) GuardState.verdict else null

		// وضعیت
		val level = v?.level
		val (levelText, levelColor) = when {
			!Prefs.guardEnabled(this) -> Pair("نگهبان خاموش است", R.color.muted)
			level == GuardEngine.Level.CRITICAL -> Pair("خطر هنگ – در حال مدیریت", R.color.crit)
			level == GuardEngine.Level.WARN -> Pair("فشار روی سیستم", R.color.warn)
			level == GuardEngine.Level.WATCH -> Pair("در حال پایش دقیق", R.color.primary)
			level == GuardEngine.Level.OK -> Pair("سیستم روان است", R.color.ok)
			else -> Pair("در حال راه‌اندازی نگهبان...", R.color.primary)
		}
		txtLevel.text = levelText
		txtLevel.setTextColor(ContextCompat.getColor(this, levelColor))

		val reasons = v?.reasons
		txtReasons.text = if (reasons.isNullOrEmpty()) {
			if (GuardState.serviceRunning) "هیچ فشاری روی رم، پردازنده و دما دیده نمی‌شود"
			else "سرویس نگهبان هنوز گزارشی نداده است"
		} else {
			reasons.joinToString("\n") { "• $it" }
		}

		// رم
		txtRam.text = "رم: ${s.ramAvailMb} از ${s.ramTotalMb} مگابایت آزاد (${s.ramFreePercent}٪)"
		barRam.progress = s.ramUsedPercent
		barRam.progressTintList = android.content.res.ColorStateList.valueOf(
			ContextCompat.getColor(
				this,
				when {
					s.ramFreePercent <= Prefs.ramCritFree(this) -> R.color.crit
					s.ramFreePercent <= Prefs.ramWarnFree(this) -> R.color.warn
					else -> R.color.ok
				}
			)
		)

		// حافطه مجازی
		if (s.hasSwap) {
			rowSwap.visibility = View.VISIBLE
			txtSwap.text =
				"حافطه مجازی (Memory extension): ${s.swapUsedMb} از ${s.swapTotalMb} مگابایت درگیر (${s.swapUsedPercent}٪)"
			barSwap.progress = s.swapUsedPercent
		} else {
			rowSwap.visibility = View.GONE
		}

		// پردازنده
		val freqText = if (s.coreFreqMhz.isEmpty()) ""
		else " • " + s.coreFreqMhz.joinToString("/") { it.toString() } + " MHz"
		val approx = if (s.cpuLoadApprox) " (تقریبی)" else ""
		txtCpu.text = "پردازنده: ${s.cpuLoad}٪$approx$freqText"
		barCpu.progress = s.cpuLoad

		// دما
		val temp = s.bestTempC
		val tempSource = if (s.cpuTempC != null) "پردازنده" else "باتری"
		val batt = s.batteryTempC
		val battPart = if (s.cpuTempC != null && batt != null)
			" • باتری " + String.format(Locale.US, "%.1f", batt) + "°"
		else ""
		var curMaxMhz = 0
		for (f in s.coreFreqMhz) if (f > curMaxMhz) curMaxMhz = f
		val throttlePart = if (s.cpuMaxFreqMhz > 0 && curMaxMhz > 0 &&
			curMaxMhz * 100 < s.cpuMaxFreqMhz * 78
		) " • پردازنده از گرما روی $curMaxMhz از ${s.cpuMaxFreqMhz} مگاهرتز قفل شده" else ""
		txtTemp.text = if (temp == null) "دما: قابل خواندن نیست"
		else "دما ($tempSource): " + String.format(Locale.US, "%.1f", temp) +
			"°سانتی‌گراد" + battPart + throttlePart
		txtTemp.setTextColor(
			ContextCompat.getColor(
				this,
				when {
					temp == null -> R.color.muted
					temp >= Prefs.tempCrit(this) -> R.color.crit
					temp >= Prefs.tempWarn(this) -> R.color.warn
					else -> R.color.text
				}
			)
		)

		txtStorage.text = String.format(
			Locale.US,
			"حافطه داخلی: %.1f از %.0f گیگابایت آزاد",
			s.storageFreeGb,
			s.storageTotalGb
		)

		txtJank.text = if (s.jankPerSec <= 0.01f) "خودآزمون روانی: بدون افت فریم"
		else String.format(Locale.US, "خودآزمون روانی: %.1f فریم در ثانیه جا می‌ماند", s.jankPerSec)

		// کارنامه
		val sb = StringBuilder()
		sb.append("پاکسازی‌ها: ").append(Prefs.cleanCount(this))
		sb.append(" • رم آزادشده: ").append(Prefs.freedTotalMb(this)).append(" مگابایت")
		sb.append(" • موارد خطر هنگ: ").append(Prefs.hangCount(this))
		if (GuardState.lastManualFreedMb >= 0L) {
			sb.append("\nآخرین پاکسازی دستی: ")
				.append(GuardState.lastManualFreedMb).append(" مگابایت از ")
				.append(GuardState.lastManualKilled).append(" برنامه")
		}
		sb.append("\nسرویس: ").append(if (GuardState.serviceRunning) "فعال و در حال پایش" else "غیرفعال")
		txtSession.text = sb.toString()

		txtDevice.text = DeviceProfile.summary(this)

		// دسترسی‌ها
		val batteryOk = isIgnoringBatteryOptimizations()
		txtPermBattery.text = if (batteryOk)
			"✅ محدودیت باتری برداشته شده – سرویس دائمی می‌ماند"
		else "⚠️ محدودیت باتری فعال است – سیستم ممکن است نگهبان را بکشد"
		txtPermBattery.setTextColor(
			ContextCompat.getColor(this, if (batteryOk) R.color.ok else R.color.warn)
		)

		val usageOk = UsageHelper.hasPermission(this)
		txtPermUsage.text = if (usageOk)
			"✅ آمار مصرف فعال – برنامه‌های در حال استفاده بسته نمی‌شوند"
		else "⚠️ بدون این دسترسی، نگهبان نمی‌داند چه برنامه‌ای تازه استفاده شده"
		txtPermUsage.setTextColor(
			ContextCompat.getColor(this, if (usageOk) R.color.ok else R.color.warn)
		)

		renderLog()
	}

	private fun renderLog() {
		containerLog.removeAllViews()
		val entries = GuardLog.all(this)
		if (entries.isEmpty()) {
			containerLog.addView(logLine("—", "هنوز رویدادی ثبت نشده", R.color.muted))
			return
		}
		var shown = 0
		for (e in entries) {
			if (shown >= 14) break
			val color = when (e.level) {
				GuardLog.CRIT -> R.color.crit
				GuardLog.WARN -> R.color.warn
				else -> R.color.muted
			}
			containerLog.addView(logLine(timeFmt.format(Date(e.time)), e.text, color))
			shown++
		}
	}

	private fun logLine(time: String, text: String, colorRes: Int): View {
		val tv = TextView(this)
		tv.text = "$time  $text"
		tv.textSize = 12f
		tv.setTextColor(ContextCompat.getColor(this, colorRes))
		tv.gravity = Gravity.START
		tv.setPadding(0, 6, 0, 6)
		return tv
	}

	// ---------------- دسترسی‌ها ----------------

	private fun isIgnoringBatteryOptimizations(): Boolean {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true
		return try {
			val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
			pm.isIgnoringBatteryOptimizations(packageName)
		} catch (t: Throwable) {
			false
		}
	}

	private fun requestBatteryExemption() {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
		try {
			val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
			intent.data = Uri.parse("package:$packageName")
			startActivity(intent)
		} catch (t: Throwable) {
			try {
				startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
			} catch (t2: Throwable) {
				Toast.makeText(this, "در تنطیمات > باتری را دستی تنطیم کن", Toast.LENGTH_LONG).show()
			}
		}
	}

	private fun openUsageAccess() {
		try {
			startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
			Toast.makeText(this, "در لیست، نگهبان سیستم را پیدا و فعال کن", Toast.LENGTH_LONG).show()
		} catch (t: Throwable) {
			Toast.makeText(this, "این صفحه در دستگاه پیدا نشد", Toast.LENGTH_SHORT).show()
		}
	}

	private fun openAutostart() {
		val candidates = listOf(
			ComponentName(
				"com.miui.securitycenter",
				"com.miui.permcenter.autostart.AutoStartManagementActivity"
			),
			ComponentName(
				"com.miui.securitycenter",
				"com.miui.powercenter.PowerSettings"
			)
		)
		for (component in candidates) {
			try {
				val intent = Intent()
				intent.component = component
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
				startActivity(intent)
				return
			} catch (t: Throwable) {
				// برو سراغ گزینه بعدی
			}
		}
		try {
			val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
			intent.data = Uri.parse("package:$packageName")
			startActivity(intent)
			Toast.makeText(
				this,
				"در این صفحه Autostart و محدودیت باتری را روی حالت بدون محدودیت بگذار",
				Toast.LENGTH_LONG
			).show()
		} catch (t: Throwable) {
			// ignore
		}
	}

	private fun askNotificationPermission() {
		if (Build.VERSION.SDK_INT < 33) return
		try {
			val granted = ContextCompat.checkSelfPermission(
				this,
				Manifest.permission.POST_NOTIFICATIONS
			) == PackageManager.PERMISSION_GRANTED
			if (!granted) {
				ActivityCompat.requestPermissions(
					this,
					arrayOf(Manifest.permission.POST_NOTIFICATIONS),
					77
				)
			}
		} catch (t: Throwable) {
			// ignore
		}
	}
}
