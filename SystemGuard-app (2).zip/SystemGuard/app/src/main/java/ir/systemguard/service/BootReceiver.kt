package ir.systemguard.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import ir.systemguard.data.GuardLog
import ir.systemguard.data.Prefs

/** بعد از روشن شدن گوشی یا به‌روزرسانی برنامه، نگهبان را دوباره بالا می‌آورد. */
class BootReceiver : BroadcastReceiver() {

	override fun onReceive(context: Context, intent: Intent?) {
		if (!Prefs.guardEnabled(context) || !Prefs.startOnBoot(context)) return
		try {
			GuardService.start(context)
			WatchdogReceiver.schedule(context)
			GuardLog.add(context, GuardLog.INFO, "نگهبان پس از روشن شدن گوشی فعال شد")
		} catch (t: Throwable) {
			// ignore
		}
	}
}
