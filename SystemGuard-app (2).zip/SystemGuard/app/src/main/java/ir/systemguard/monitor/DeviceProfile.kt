package ir.systemguard.monitor

import android.content.Context
import android.os.Build
import ir.systemguard.data.Prefs

/** شناسایی گوشی و تنطیم آستانه‌های متناسب با همان گوشی. */
object DeviceProfile {

	class Info(
		val model: String,
		val brand: String,
		val androidRelease: String,
		val sdk: Int,
		val cores: Int,
		val ramTotalMb: Long,
		val swapTotalMb: Long,
		val maxFreqMhz: Int,
		val miui: String?
	)

	fun info(context: Context): Info {
		val mem = StatsCollector.readMemInfo()
		val snapshot = StatsCollector.sample(context)
		return Info(
			model = Build.MODEL ?: "?",
			brand = (Build.BRAND ?: "?"),
			androidRelease = Build.VERSION.RELEASE ?: "?",
			sdk = Build.VERSION.SDK_INT,
			cores = Runtime.getRuntime().availableProcessors(),
			ramTotalMb = (mem["MemTotal"] ?: 0L) / 1024L,
			swapTotalMb = (mem["SwapTotal"] ?: 0L) / 1024L,
			maxFreqMhz = snapshot.cpuMaxFreqMhz,
			miui = prop("ro.miui.ui.version.name")
		)
	}

	fun summary(context: Context): String {
		val i = info(context)
		val sb = StringBuilder()
		sb.append(i.brand).append(" ").append(i.model)
		sb.append(" • اندروید ").append(i.androidRelease)
		if (i.miui != null) sb.append(" • MIUI ").append(i.miui)
		sb.append("\nرم کل: ").append(i.ramTotalMb).append(" مگابایت")
		if (i.swapTotalMb > 0) {
			sb.append(" + حافطه مجازی ").append(i.swapTotalMb).append(" مگابایت")
		}
		sb.append("\nپردازنده: ").append(i.cores).append(" هسته‌ای")
		if (i.maxFreqMhz > 0) sb.append(" تا ").append(i.maxFreqMhz).append(" مگاهرتز")
		return sb.toString()
	}

	/** آستانه‌های پیشنهادی را روی همین دستگاه اعمال می‌کند. */
	fun applyTuned(context: Context): String {
		val i = info(context)
		val ram = i.ramTotalMb

		val warnFree: Int
		val critFree: Int
		when {
			ram <= 2600L -> {
				warnFree = 24
				critFree = 15
			}
			ram <= 4600L -> {
				warnFree = 18
				critFree = 12
			}
			ram <= 7000L -> {
				warnFree = 15
				critFree = 10
			}
			else -> {
				warnFree = 12
				critFree = 8
			}
		}

		// پردازنده‌های میان‌رده زودتر داغ می‌شوند
		val tempWarn = if (i.maxFreqMhz in 1..2200) 41 else 43
		val tempCrit = tempWarn + 4
		val interval = if (i.cores <= 4) 8 else 6

		Prefs.setRamWarnFree(context, warnFree)
		Prefs.setRamCritFree(context, critFree)
		Prefs.setTempWarn(context, tempWarn)
		Prefs.setTempCrit(context, tempCrit)
		Prefs.setIntervalSec(context, interval)
		Prefs.setCooldownSec(context, 90)
		Prefs.setAutoClean(context, true)
		Prefs.setAlerts(context, true)

		val sb = StringBuilder()
		sb.append("آستانه‌ها برای رم ").append(ram).append(" مگابایت تنطیم شد: ")
		sb.append("هشدار زیر ").append(warnFree).append("٪ آزاد، ")
		sb.append("بحرانی زیر ").append(critFree).append("٪، ")
		sb.append("دمای هشدار ").append(tempWarn).append("°")
		return sb.toString()
	}

	private fun prop(key: String): String? {
		return try {
			val clazz = Class.forName("android.os.SystemProperties")
			val method = clazz.getMethod("get", String::class.java)
			val value = method.invoke(null, key) as? String
			if (value.isNullOrBlank()) null else value
		} catch (t: Throwable) {
			null
		}
	}
}
