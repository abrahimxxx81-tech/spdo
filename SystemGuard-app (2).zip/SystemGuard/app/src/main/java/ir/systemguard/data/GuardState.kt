package ir.systemguard.data

import ir.systemguard.engine.GuardEngine
import ir.systemguard.monitor.StatsSnapshot

/** وضعیت زندهٔ نگهبان که سرویس می‌نویسد و رابط کاربری می‌خواند. */
object GuardState {

	@Volatile
	var serviceRunning: Boolean = false

	@Volatile
	var snapshot: StatsSnapshot? = null

	@Volatile
	var verdict: GuardEngine.Verdict? = null

	@Volatile
	var updatedAt: Long = 0L

	@Volatile
	var busy: Boolean = false

	@Volatile
	var lastManualFreedMb: Long = -1L

	@Volatile
	var lastManualKilled: Int = 0
}
