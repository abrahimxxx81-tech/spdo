package ir.systemguard.monitor

import android.view.Choreographer

/**
 * اندازه‌گیری فریم‌های جا مانده (خودآزمون لگ).
 * فقط وقتی صفحه برنامه باز است فعال می‌شود تا باتری نسوزد.
 */
object JankMonitor : Choreographer.FrameCallback {

	private var running = false
	private var lastFrameNs = 0L
	private var windowStartNs = 0L
	private var jankFrames = 0

	@Volatile
	var jankPerSec: Float = 0f
		private set

	fun start() {
		if (running) return
		running = true
		lastFrameNs = 0L
		windowStartNs = 0L
		jankFrames = 0
		try {
			Choreographer.getInstance().postFrameCallback(this)
		} catch (t: Throwable) {
			running = false
		}
	}

	fun stop() {
		running = false
		try {
			Choreographer.getInstance().removeFrameCallback(this)
		} catch (t: Throwable) {
			// ignore
		}
		jankPerSec = 0f
	}

	override fun doFrame(frameTimeNanos: Long) {
		if (!running) return

		if (lastFrameNs != 0L) {
			val deltaMs = (frameTimeNanos - lastFrameNs) / 1_000_000f
			if (deltaMs > 32f) {
				val dropped = (deltaMs / 16.7f).toInt() - 1
				jankFrames += if (dropped > 0) dropped else 1
			}
		}
		lastFrameNs = frameTimeNanos
		if (windowStartNs == 0L) windowStartNs = frameTimeNanos

		val elapsedSec = (frameTimeNanos - windowStartNs) / 1_000_000_000f
		if (elapsedSec >= 1f) {
			jankPerSec = jankFrames / elapsedSec
			jankFrames = 0
			windowStartNs = frameTimeNanos
		}

		try {
			Choreographer.getInstance().postFrameCallback(this)
		} catch (t: Throwable) {
			running = false
		}
	}
}
