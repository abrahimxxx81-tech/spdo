package ir.systemguard.engine

import android.content.Context
import android.os.Build
import android.os.PowerManager
import ir.systemguard.data.GuardLog
import ir.systemguard.data.Prefs
import ir.systemguard.monitor.StatsSnapshot

/**
 * مغز تصمیم‌گیری.
 *
 * نسخهٔ ۱.۱ بر اساس دادهٔ واقعی همین گوشی بازنویسی شد:
 * ۱. اگر گوشی داغ است، پاکسازی انجام نمی‌شود؛ چون خود پاکسازی بار پردازنده و گرما را بالا می‌برد.
 * ۲. اگر پاکسازی چیزی آزاد نکرد، فاصلهٔ پاکسازی بعدی خودکار دو برابر می‌شود (تا ۱۵ دقیقه).
 * ۳. فشار رم باید دو نوبت پشت‌سرهم دیده شود تا اقدام انجام شود.
 * ۴. قفل شدن فرکانس پردازنده (throttle) به‌عنوان علت مستقل لگ تشخیص داده می‌شود.
 */
class GuardEngine(private val context: Context) {

	enum class Level { OK, WATCH, WARN, CRITICAL }

	class Verdict(
		val level: Level,
		val reasons: List<String>,
		val cleaned: Boolean,
		val freedMb: Long,
		val killed: Int
	)

	private val cleaner = AppCleaner(context)
	private var lastCleanAt = 0L
	private var highCpuStreak = 0
	private var pressureStreak = 0
	private var throttleStreak = 0
	private var backoff = 1
	private var lastHotSkipLogAt = 0L
	private var lastLevel = Level.OK

	fun evaluate(s: StatsSnapshot): Verdict {
		val reasons = ArrayList<String>()
		var level = Level.OK

		// ---------- رم ----------
		val freePercent = s.ramFreePercent
		val warnFree = Prefs.ramWarnFree(context)
		val critFree = Prefs.ramCritFree(context)

		if (freePercent <= critFree || s.lowMemory) {
			level = raise(level, Level.CRITICAL)
			reasons.add("رم تقریباً پر است (فقط $freePercent٪ آزاد – ${s.ramAvailMb} مگابایت)")
		} else if (freePercent <= warnFree) {
			level = raise(level, Level.WARN)
			reasons.add("رم در حال پر شدن است ($freePercent٪ آزاد)")
		} else if (freePercent <= warnFree + 6) {
			level = raise(level, Level.WATCH)
		}

		// ---------- حافطه مجازی / Memory extension ----------
		if (s.hasSwap && s.swapUsedPercent >= 80) {
			level = raise(level, Level.WARN)
			reasons.add("حافطه مجازی ${s.swapUsedPercent}٪ پر شده – این قابلیت را در تنطیمات MIUI خاموش کن")
		} else if (s.hasSwap && s.swapUsedPercent >= 50) {
			level = raise(level, Level.WATCH)
			reasons.add("حافطه مجازی ${s.swapUsedPercent}٪ درگیر است (رم روی حافطهٔ کند داخلی)")
		}

		// ---------- پردازنده ----------
		if (s.cpuLoad >= 85) highCpuStreak++ else highCpuStreak = 0
		if (highCpuStreak >= 3) {
			level = raise(level, Level.WARN)
			reasons.add("پردازنده مدتی است روی ${s.cpuLoad}٪ مانده")
		}

		// ---------- قفل شدن فرکانس از گرما (throttle) ----------
		var curMax = 0
		for (f in s.coreFreqMhz) if (f > curMax) curMax = f
		val throttled = s.cpuMaxFreqMhz > 0 && curMax > 0 &&
			curMax * 100 < s.cpuMaxFreqMhz * 78
		if (throttled) throttleStreak++ else throttleStreak = 0
		if (throttleStreak >= 3) {
			level = raise(level, Level.WARN)
			reasons.add(
				"پردازنده روی $curMax از ${s.cpuMaxFreqMhz} مگاهرتز قفل شده – " +
					"مهم‌ترین علت لگ بازی همین است و ریشه‌اش گرماست"
			)
		}

		// ---------- دما ----------
		val temp = s.bestTempC
		val tempWarn = Prefs.tempWarn(context)
		val tempCrit = Prefs.tempCrit(context)
		if (temp != null) {
			if (temp >= tempCrit) {
				level = raise(level, Level.CRITICAL)
				reasons.add("دمای ${fmt(temp)}° – پردازنده دارد خودرا خفه می‌کند (throttle)")
			} else if (temp >= tempWarn) {
				level = raise(level, Level.WARN)
				reasons.add("دمای ${fmt(temp)}° – گوشی داغ شده")
			}
		}

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && s.thermalStatus >= 0) {
			if (s.thermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
				level = raise(level, Level.CRITICAL)
				reasons.add("سیستم وارد محدودیت حرارتی شده است")
			} else if (s.thermalStatus >= PowerManager.THERMAL_STATUS_MODERATE) {
				level = raise(level, Level.WARN)
				reasons.add("محدودیت حرارتی ملایم فعال شده")
			}
		}

		// ---------- لگ واقعی ----------
		if (s.jankPerSec >= 10f) {
			level = raise(level, Level.WARN)
			reasons.add("افت فریم محسوس است (${s.jankPerSec.toInt()} فریم در ثانیه جا می‌ماند)")
		}

		// ---------- حافطه داخلی ----------
		if (s.storageTotalGb > 0f && s.storageFreeGb < 5f) {
			level = raise(level, Level.WARN)
			reasons.add("حافطه داخلی کمتر از ۵ گیگ آزاد دارد")
		}

		// ---------- اقدام ----------
		var cleaned = false
		var freed = 0L
		var killed = 0

		val now = System.currentTimeMillis()
		val hot = temp != null && temp >= tempCrit

		// فشار واقعی رم؛ حافطهٔ مجازی به‌تنهایی دلیل پاکسازی نیست چون در MIUI همیشه درگیر است.
		val ramPressure = freePercent <= warnFree || s.lowMemory
		val swapPressure = s.hasSwap && s.swapUsedPercent >= 85 && freePercent <= warnFree + 8
		val pressure = ramPressure || swapPressure
		if (pressure) pressureStreak++ else pressureStreak = 0

		val baseCooldown = Prefs.cooldownSec(context) * 1000L
		var wait = baseCooldown * backoff
		if (wait > MAX_COOLDOWN_MS) wait = MAX_COOLDOWN_MS
		if (level == Level.CRITICAL && !hot) wait /= 2

		val due = now - lastCleanAt >= wait

		if (Prefs.autoClean(context) && pressure && pressureStreak >= 2 && due && !hot) {
			val r = cleaner.clean(level == Level.CRITICAL)
			lastCleanAt = now
			cleaned = true
			freed = r.freedMb
			killed = r.killed

			// اگر پاکسازی بی‌فایده بود، دفعهٔ بعد دیرتر و اگر مؤثر بود، زودتر.
			if (freed < 60L) {
				backoff = if (backoff < 8) backoff * 2 else 8
			} else if (freed >= 200L) {
				backoff = 1
			}

			GuardLog.add(
				context,
				if (freed >= 60L) GuardLog.WARN else GuardLog.INFO,
				if (freed >= 60L)
					"پاکسازی: $killed برنامهٔ پس‌زمینه بسته شد، $freed مگابایت آزاد شد"
				else
					"پاکسازی اثر نداشت ($killed برنامه) – رم مشکل اصلی نیست، فاصلهٔ پاکسازی زیاد شد"
			)
		} else if (Prefs.autoClean(context) && pressure && hot && due &&
			now - lastHotSkipLogAt > 5L * 60L * 1000L
		) {
			lastHotSkipLogAt = now
			GuardLog.add(
				context,
				GuardLog.CRIT,
				"پاکسازی متوقف شد چون گوشی ${fmt(temp ?: 0f)}° است؛ در این دما هر کاری گرما را بیشتر می‌کند. " +
					"چند دقیقه گوشی را رها کن و قاب را بردار."
			)
		}

		if (level == Level.CRITICAL && lastLevel != Level.CRITICAL) {
			Prefs.bumpHangCount(context)
			GuardLog.add(context, GuardLog.CRIT, "خطر هنگ: " + reasons.joinToString(" • "))
		} else if (level == Level.WARN && lastLevel == Level.OK) {
			GuardLog.add(context, GuardLog.WARN, reasons.joinToString(" • "))
		}
		lastLevel = level

		return Verdict(level, reasons, cleaned, freed, killed)
	}

	fun manualClean(): AppCleaner.Result {
		val r = cleaner.clean(true)
		lastCleanAt = System.currentTimeMillis()
		backoff = 1
		GuardLog.add(
			context,
			GuardLog.INFO,
			"پاکسازی دستی: ${r.killed} برنامه بسته شد، ${r.freedMb} مگابایت آزاد شد"
		)
		return r
	}

	private fun raise(current: Level, candidate: Level): Level =
		if (candidate.ordinal > current.ordinal) candidate else current

	private fun fmt(v: Float): String = String.format("%.1f", v)

	companion object {
		private const val MAX_COOLDOWN_MS = 15L * 60L * 1000L
	}
}
